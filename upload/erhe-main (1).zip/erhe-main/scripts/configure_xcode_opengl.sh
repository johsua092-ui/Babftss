#!/bin/bash

# LD=ld.lld-15 CC=clang-15 CXX=clang++-15 scripts/configure_ninja.sh
#-DCMAKE_EXE_LINKER_FLAGS=-fuse-ld=lld \
#-DCMAKE_SHARED_LINKER_FLAGS=-fuse-ld=lld \

cmake \
    -G "Xcode" \
    -B build_xcode_opengl \
    -S . \
    -DCMAKE_EXPORT_COMPILE_COMMANDS=1 \
    -Wno-dev \
    -DERHE_BUILD_TESTS=ON \
    -DERHE_FONT_RASTERIZATION_LIBRARY=freetype \
    -DERHE_GLTF_LIBRARY=fastgltf \
    -DERHE_GRAPHICS_API=opengl \
    -DERHE_GUI_LIBRARY=imgui \
    -DERHE_NAVIGATION_LIBRARY=none \
    -DERHE_PHYSICS_LIBRARY=jolt \
    -DERHE_PROFILE_LIBRARY=none \
    -DERHE_RAYTRACE_LIBRARY=bvh \
    -DERHE_SPIRV=OFF \
    -DERHE_SVG_LIBRARY=plutosvg \
    -DERHE_TEXT_LAYOUT_LIBRARY=harfbuzz \
    -DERHE_USE_ASAN:BOOL=OFF \
    -DERHE_USE_PRECOMPILED_HEADERS=ON \
    -DERHE_VOXEL_LIBRARY=openvdb \
    -DERHE_WINDOW_LIBRARY=sdl \
    -DERHE_XR_LIBRARY=none \
