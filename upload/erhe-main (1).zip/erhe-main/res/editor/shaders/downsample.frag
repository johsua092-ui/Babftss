layout(location = 0) in vec2 v_texcoord;

// Must have one of these
//  - #define SOURCE s_input
//  - #define SOURCE s_downsample

void main()
{
    vec2 texel_scale = post_processing.texel_scale;

    const float weight0  = 1.0 / 32.0;
    const float weight1  = 2.0 / 32.0;
    const float weight2  = 1.0 / 32.0;
    const float weight3  = 4.0 / 32.0;
    const float weight4  = 4.0 / 32.0;
    const float weight5  = 2.0 / 32.0;
    const float weight6  = 4.0 / 32.0;
    const float weight7  = 2.0 / 32.0;
    const float weight8  = 4.0 / 32.0;
    const float weight9  = 4.0 / 32.0;
    const float weight10 = 1.0 / 32.0;
    const float weight11 = 2.0 / 32.0;
    const float weight12 = 1.0 / 32.0;

    vec3 sample0  = weight0  * textureLod(SOURCE, v_texcoord + texel_scale * vec2(-2.0, -2.0), 0.0).rgb;
    vec3 sample1  = weight1  * textureLod(SOURCE, v_texcoord + texel_scale * vec2( 0.0, -2.0), 0.0).rgb;
    vec3 sample2  = weight2  * textureLod(SOURCE, v_texcoord + texel_scale * vec2( 2.0, -2.0), 0.0).rgb;
    vec3 sample3  = weight3  * textureLod(SOURCE, v_texcoord + texel_scale * vec2(-1.0, -1.0), 0.0).rgb;
    vec3 sample4  = weight4  * textureLod(SOURCE, v_texcoord + texel_scale * vec2( 1.0, -1.0), 0.0).rgb;
    vec3 sample5  = weight5  * textureLod(SOURCE, v_texcoord + texel_scale * vec2(-2.0,  0.0), 0.0).rgb;
    vec3 sample6  = weight6  * textureLod(SOURCE, v_texcoord + texel_scale * vec2( 0.0,  0.0), 0.0).rgb;
    vec3 sample7  = weight7  * textureLod(SOURCE, v_texcoord + texel_scale * vec2( 2.0,  0.0), 0.0).rgb;
    vec3 sample8  = weight8  * textureLod(SOURCE, v_texcoord + texel_scale * vec2(-1.0,  1.0), 0.0).rgb;
    vec3 sample9  = weight9  * textureLod(SOURCE, v_texcoord + texel_scale * vec2( 1.0,  1.0), 0.0).rgb;
    vec3 sample10 = weight10 * textureLod(SOURCE, v_texcoord + texel_scale * vec2(-2.0,  2.0), 0.0).rgb;
    vec3 sample11 = weight11 * textureLod(SOURCE, v_texcoord + texel_scale * vec2( 0.0,  2.0), 0.0).rgb;
    vec3 sample12 = weight12 * textureLod(SOURCE, v_texcoord + texel_scale * vec2( 2.0,  2.0), 0.0).rgb;

    out_color      = vec4(0.0, 0.0, 0.0, 1.0);
    out_color.rgb += sample0;
    out_color.rgb += sample1;
    out_color.rgb += sample2;
    out_color.rgb += sample3;
    out_color.rgb += sample4;
    out_color.rgb += sample5;
    out_color.rgb += sample6;
    out_color.rgb += sample7;
    out_color.rgb += sample8;
    out_color.rgb += sample9;
    out_color.rgb += sample10;
    out_color.rgb += sample11;
    out_color.rgb += sample12;
}
