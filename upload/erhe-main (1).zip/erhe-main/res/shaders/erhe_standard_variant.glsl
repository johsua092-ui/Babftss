#ifndef ERHE_STANDARD_VARIANT_GLSL
#define ERHE_STANDARD_VARIANT_GLSL

// Documentation header for the editor's standard lit shader variants.
//
// Shader_variant_cache emits the per-axis flags / counts that match the
// (material, mesh, scene) Shader_key. The shader source can rely on:
//   - ERHE_USE_VERTEX_VARYING_X => ERHE_ATTRIBUTE_a_X (the underlying
//     attribute is always declared when the varying is enabled),
//   - ERHE_USE_SKINNING => the joint attributes are present,
//   - ERHE_LIGHT_COUNT_*_* being a compile-time integer literal so the
//     light loops unroll or vanish,
//   - ERHE_BXDF_MODEL being a compile-time integer literal mapped from
//     erhe::primitive::Bxdf_model.
//
// No non-variant fallback path exists; if you hit an "undefined macro"
// error in standard.frag / standard.vert, it means a code path is
// compiling them without going through Shader_variant_cache -- fix the
// call site, do not reintroduce fallback macros.

// ERHE_VARIANT_POSITION_PASS is a derived gate. ERHE_VARIANT_DEPTH_ONLY,
// ERHE_VARIANT_ID_RENDER and ERHE_VARIANT_POINTS all skip the lit / debug
// varyings -- the vertex shader only needs gl_Position plus, per variant, a
// couple of tiny outputs (ID render: two flat ints; points: gl_PointSize +
// a flat color); the fragment shader either has no body (depth-only) or
// emits a packed ID color / flat point color directly. Use this gate at
// every "skip lit machinery" #if so the variants stay in lock-step.
// ERHE_VARIANT_FACE_ID_SEED is the ID-buffer edge-line method's seed pass: it
// renders the visible content fill outputting each fragment's encoded face id
// (per-primitive base + facet id, the SAME registry namespace the EDGE_LINES_FROM_ID
// fill and the edge-id pre-pass use) into a dedicated face-ID buffer with depth
// test, so the buffer holds the FRONTMOST visible face id per pixel. The edge-id
// pre-pass then samples that buffer to reject edge fragments that do not land on
// their own face's visible surface. Like ID_RENDER it skips the lit / debug
// machinery (it only needs gl_Position plus the flat face-id varying), so it is a
// position pass.
#if defined(ERHE_VARIANT_DEPTH_ONLY) || defined(ERHE_VARIANT_ID_RENDER) || defined(ERHE_VARIANT_SHADOW_DISTANCE) || defined(ERHE_VARIANT_SHADOW_CUBE) || defined(ERHE_VARIANT_POINTS) || defined(ERHE_VARIANT_FACE_ID_SEED)
#  define ERHE_VARIANT_POSITION_PASS 1
#endif

// ERHE_VARIANT_SHADOW_CUBE is a position pass (no lit / debug varyings), but
// unlike the other position-pass variants its fragment shader needs the world
// position to compute the radial distance to the point light, so v_position is
// kept (see standard.vert / standard.frag). Use this gate to re-enable the
// v_position varying without pulling in the rest of the lit machinery.
#if !defined(ERHE_VARIANT_POSITION_PASS) || defined(ERHE_VARIANT_SHADOW_CUBE)
#  define ERHE_USE_VARYING_POSITION 1
#endif

// Bxdf_model enum values. Keep in sync with erhe::primitive::Bxdf_model.
#define ERHE_BXDF_MODEL_UNLIT                    0
#define ERHE_BXDF_MODEL_ISOTROPIC_BRDF           1
#define ERHE_BXDF_MODEL_ANISOTROPIC_BRDF         2
#define ERHE_BXDF_MODEL_ANISOTROPIC_SLOPE        3
#define ERHE_BXDF_MODEL_ANISOTROPIC_ENGINE_READY 4

// Material_blending_mode enum values. Keep in sync with
// erhe::primitive::Material_blending_mode. The fragment shader branches
// on ERHE_MATERIAL_BLENDING_MODE to pick the per-fragment output policy:
//   OPAQUE      -> straight color, alpha = 1.
//   ALPHA_BLEND -> premultiplied color + opacity in alpha (blend state
//                  must enable premultiplied alpha).
//   MULTIPLY    -> lit color (clamped); blend state does dst * src.
//   ADD         -> lit color; blend state adds onto framebuffer.
//   SUBTRACT    -> lit color; blend state does reverse subtract.
//   SCREEN_DOOR -> Bayer 4x4 dithered discard against sampled alpha;
//                  blend stays disabled.
//   ALPHA_TEST  -> hard discard when sampled alpha < material.alpha_cutoff;
//                  blend stays disabled.
#define ERHE_MATERIAL_BLENDING_MODE_OPAQUE       0
#define ERHE_MATERIAL_BLENDING_MODE_ALPHA_BLEND  1
#define ERHE_MATERIAL_BLENDING_MODE_MULTIPLY     2
#define ERHE_MATERIAL_BLENDING_MODE_ADD          3
#define ERHE_MATERIAL_BLENDING_MODE_SUBTRACT     4
#define ERHE_MATERIAL_BLENDING_MODE_SCREEN_DOOR  5
#define ERHE_MATERIAL_BLENDING_MODE_ALPHA_TEST   6

#endif // ERHE_STANDARD_VARIANT_GLSL
